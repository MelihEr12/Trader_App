#ifndef STOCKS_H
#define STOCKS_H
#include <string>
using namespace std;

class Stocks
{
public:
    int num;
    int supply;
    double price;
    string name ;



    double buy()
    {
        supply=supply-num;
        price= price+((price*num)*0.01);
        return price;
    }

    double sell()
    {
        supply=supply+num;
        price=price-((price*num)*0.01);
        return price;
    };


};

struct user{
    string name;
    double budget;
    double piece;
};

#endif // STOCKS_H
