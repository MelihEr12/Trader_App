#include "stocks.h"

Stocks::Stocks()
{

}
