#ifndef STOCKS_H
#define STOCKS_H
#define iostream
#include <string>




#endif // STOCKS_H
